package semana03;

public class Math01 {

	public static void main(String[] args) {
		
		int a = 10, b = 20, c = 30;
		
		System.out.println(Math.max(a,b));
		System.out.println(Math.max(a,Math.max(b,c)));
		
		System.out.println(Math.random());
		

	}

}
